<?php

include_once "../login/database.php";

function getTickets()
{
    global $mysqli;

    $sql = "SELECT * FROM karte ORDER BY id DESC";

    $result = $mysqli->query($sql);

    $ret = [];
    while ($row = $result->fetch_array()) {
        $ret[] = $row;
    }
    return $ret;
}

function getSingleTicket($ticketId)
{
    global $mysqli;

    $ticketId = $mysqli->escape_string($ticketId);

    $sql = "SELECT * FROM karte WHERE id = {$ticketId}";
    $result = $mysqli->query($sql);
    return $result->fetch_assoc();
}

function deleteTicket($ticketId)
{
    global $mysqli;

    $ticketId = $mysqli->escape_string($ticketId);

    $sql = "DELETE FROM `karte` WHERE `karte`.`id` = {$ticketId}";
    $mysqli->query($sql);
}

function updateTicket($ticketId, $naziv, $cijena)
{
    global $mysqli;

    $sql = "UPDATE `karte` SET `naziv` = '{$naziv}', `cijena` = {$cijena} WHERE `karte`.`id` = {$ticketId}";
    $mysqli->query($sql);

}

function insertTicket($naziv, $cijena)
{
    global $mysqli;

    $sql = "INSERT INTO `karte` (`id`, `naziv`, `cijena`) VALUES (NULL, '{$naziv}', '{$cijena}');";
    $mysqli->query($sql);

}

?>
