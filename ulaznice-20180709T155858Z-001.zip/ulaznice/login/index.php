<?php
require 'database.php';
session_start();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
  if(isset($_POST['login'])) {
    require 'login.php';
  }
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Prijava</title>

    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	  <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="../css/main.css" rel="stylesheet" type="text/css">
  </head>
  <body>
    <div class="container-fluid logScreen flexcol">
      <h3 class="logTitle text-center">
        Prijavite se na svoj račun
      </h3>
      <form action="index.php" method="post" class="logForm flexcol" autocomplete="off">
        <input type="text" required placeholder="E-mail" name="email" class="logInput">
        <input type="password" required placeholder="Lozinka" name="password" class="logInput">
        <input type="submit" class="btn btn-success loginButton" name="login" value="Prijava">
      </form>
      <p class="signOption">Nemate račun? <a href="register.php" class="signUp">Registriraj se.</a></p>
    </div>
  </body>
</html>
