<?php
session_start();
error_reporting(0);

include_once "login/database.php";
include_once "./tickets/tickets.php";

$isLoggedIn = $_SESSION['logged_in'] == true ? true : false;

if ($isLoggedIn) {
    $option = "Prijava / Registracija";
    $link = "index.php";
} else {
    $option = "Odjava";
    $link = "logout.php";
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main.css" type="text/css">
    <title>Prodaja Ulaznica</title>
</head>
<body>
<nav id="myNavbar" class="navbar fixed-top navbar-toggleable-md navbar-light bg-faded">
    <a class="navbar-brand mr-auto" href="#">ULAZNICE</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item meni"><a class="nav-link" href="index.php">Početna</a></li>
            <li class="nav-item meni"><a class="nav-link" href="ulaznice.php">Ulaznice</a></li>
            <li class="nav-item meni"><a class="nav-link" href="#kontakt">Kontakt</a></li>
            <li class="nav-item meni"><a class="nav-link" href="login/<?php echo $link ?>"><?php echo $option ?></a></li>
        </ul>
    </div>
</nav>

<?php
$tickets = getTickets();
?>

<div class="container">
    <h1>Popis ulaznica</h1>

    <?php if(isset($_GET['delete'])){
        deleteTicket($_GET['delete']);
        ?>
        <div class="delete_single">
            Obrisana karta "<?php echo $_GET['naziv']; ?>"
            <a href="/ulaznice.php" class="close_btn">X</a>
        </div>
    <?php } ?>

    <?php if(isset($_GET['edit'])){
        $ticket = getSingleTicket($_GET['edit']);
        ?>
        <div class="edit_single">
            <a href="/ulaznice.php" class="close_btn">X</a>
            <h3>Uredi kartu "<?php echo $ticket['naziv']; ?>"</h3>

            <form action="" method="GET" id="form_update">
            <div class="form-group row">
                <label for="naziv" class="col-2 col-form-label">Naziv</label>
                <div class="col-10">
                    <input class="form-control" type="text" name="naziv" value="<?php echo $ticket['naziv']; ?>" id="naziv" >
                </div>
            </div>

            <div class="form-group row">
                <label for="cijena" class="col-2 col-form-label">Cijena</label>
                <div class="col-10">
                    <input class="form-control" type="text" name="cijena" value="<?php echo $ticket['cijena']; ?>" id="cijena" >
                </div>
            </div>
            <input class="form-control" type="hidden" name="update" value="<?php echo $ticket['id']; ?>" >
            </form>
            <button type="submit" class="btn btn-primary" form="form_update" >Uredi</button>
        </div>
    <?php } ?>

    <?php if(isset($_GET['update'])){
        $ticketId = $_GET['update'];
        $naziv  = $_GET['naziv'];
        $cijena = $_GET['cijena'];

        updateTicket($ticketId, $naziv, $cijena);
    } ?>

    <?php if(isset($_GET['create'])){
        $ticket = getSingleTicket($_GET['create']);
        ?>
        <div class="edit_single">
            <a href="/ulaznice.php" class="close_btn">X</a>
            <h3>Uredi novu kartu</h3>

            <form action="" method="GET" id="form_create">
                <div class="form-group row">
                    <label for="naziv" class="col-2 col-form-label">Naziv</label>
                    <div class="col-10">
                        <input class="form-control" type="text" name="naziv" value="" id="naziv" placeholder="Naziv">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="cijena" class="col-2 col-form-label">Cijena</label>
                    <div class="col-10">
                        <input class="form-control" type="text" name="cijena" value="" id="cijena" placeholder="Cijena" >
                    </div>
                </div>
                <input class="form-control" type="hidden" name="insert" value="1" >
            </form>
            <button type="submit" class="btn btn-primary" form="form_create" >Spremi</button>
        </div>
    <?php } ?>

    <?php if(isset($_GET['insert'])){
        $naziv  = $_GET['naziv'];
        $cijena = $_GET['cijena'];

        insertTicket($naziv, $cijena);

    } ?>

    <table class="table table-striped">
        <thead>
        <tr>
            <th>Id</th>
            <th>Naziv</th>
            <th>Cijena</th>
            <th></th>
            <?php
            if ($isLoggedIn) { ?>
                <th></th>
                <th></th>
            <?php } ?>
        </tr>
        </thead>
        <tbody>
        <?php foreach (getTickets() as $ticket){ ?>
        <tr>
            <td><?php echo $ticket['id'] ?></td>
            <td><?php echo $ticket['naziv'] ?></td>
            <td><?php echo $ticket['cijena'] ?></td>

            <?php if($isLoggedIn){ ?>
                <td><a href="?edit=<?php echo $ticket['id'] ?>">Uredi</a></td>
                <td><a href="?delete=<?php echo $ticket['id'] ?>&naziv=<?php echo $ticket['naziv'] ?>">Obriši</a></td>
            <?php } ?>
        </tr>
        <?php } ?>
        </tbody>
    </table>
    <?php
        if ($isLoggedIn) {
            ?>
            <a href="ulaznice.php?create=1">
                <button type="submit" class="btn btn-primary" form="form_create" >Kreiraj</button>
            </a>
            <?php
        }
    ?>
</div>

<div class="footer footer_stylized">
    <p class="text-center">S VAMA KROZ NAJLJEPŠA SJEĆANJA.</p>
</div>

<script src="https://use.fontawesome.com/f1e7ae096d.js"></script>
<script type="text/javascript" src="javascript/jquery.js"></script>
<script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
<script type="text/javascript" src="javascript/index.js"></script>
</body>
</html>
