<?php
 session_start();
 error_reporting(0);

 if ($_SESSION['logged_in'] != true) {
   $option = "Prijava / Registracija";
   $link = "index.php";
 } else {
   $option = "Odjava";
   $link = "logout.php";
 }
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
  	<meta http-equiv="X-UA-Compatible" content="IE=edge">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	  <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main.css" type="text/css">
    <title>Prodaja Ulaznica</title>
  </head>
  <body>
  <nav id="myNavbar" class="navbar fixed-top navbar-toggleable-md navbar-light bg-faded">
		<a class="navbar-brand mr-auto" href="#">ULAZNICE</a>
		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item meni"><a class="nav-link" href="index.php">Početna</a></li>
			    <li class="nav-item meni"><a class="nav-link" href="ulaznice.php">Ulaznice</a></li>
			    <li class="nav-item meni"><a class="nav-link" href="#kontakt">Kontakt</a></li>
			    <li class="nav-item meni"><a class="nav-link" href="login/<?php echo $link ?>"><?php echo $option ?></a></li>
			</ul>
		</div>
	</nav>
  <div class="header">
    <h2 class="headerText text-center">DOBRODOŠLI NA MJESTO GDJE ZABAVA POČINJE</h2>
  </div>
  <div class="mainContent">
    <p class="text-center">Nudimo uslugu prodaje ulaznica za različite vrste događaja: od sportskih preko glazbenih i kazališnih do konferencija i prodaje ulaziica za muzej, koncerte itd.</p>
    <p class="text-center">Naš cilj je dostupnost kupca preko što više različitih kanala prodaje - lokalno, internetom, mobilnim uređajima, kroz prodajnu mrežu...</p>
    <p class="text-center">Fleksibilnost za organizatora - prilagodbom svim vrstama događaja, prostorima, politikama cijena...</p>
    <p class="text-center">Ne živite u gradu gdje se održava događaj koji vas zanima? Uz nas to rješavate bez problema.</p>
  </div>
  <div class="poslovnice">
    <h3 class="poslovniceText text-center"> - POSLOVNICE - </h3>
    <p class="text-center">Oni koji su u blizini mjesta održavanja, imaju mogućnost prodaje ulaznice u našim poslovnicama u:</p>
    <ul class="posList">
      <li class="text-center">Zagrebu</li>
      <li class="text-center">Splitu</li>
      <li class="text-center">Rijeci</li>
      <li class="text-center">Osijeku</li>
    </ul>
  </div>
  <div class="kontakt" id="kontakt">
    <h3 class="text-center"> KONTAKT </h3>
    <div class="container-fluid formHold">
      <div class="col-md-5">
          <div class="form-area">
              <form role="form">
              <br style="clear:both">
          				<div class="form-group">
      						<input type="text" class="form-control" id="name" name="name" placeholder="Ime" required>
      					</div>
      					<div class="form-group">
      						<input type="text" class="form-control" id="email" name="email" placeholder="E-mail" required>
      					</div>
      					<div class="form-group">
      						<input type="text" class="form-control" id="subject" name="subject" placeholder="Predmet" required>
      					</div>
                <div class="form-group">
                  <textarea class="form-control" type="textarea" id="message" placeholder="Poruka" maxlength="140" rows="7"></textarea>
                  <span class="help-block"><p id="characterLeft" class="help-block ">Dosegli ste limit</p></span>
                </div>
              <button type="button" id="submit" name="submit" class="btn btn-primary pull-right">Pošalji</button>
              </form>
          </div>
        </div>
      </div>
    </div>
    <div class="footer">
      <p class="text-center">S VAMA KROZ NAJLJEPŠA SJEĆANJA.</p>
    </div>

    <script src="https://use.fontawesome.com/f1e7ae096d.js"></script>
    <script type="text/javascript" src="javascript/jquery.js"></script>
    <script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="javascript/index.js"></script>
  </body>
</html>
