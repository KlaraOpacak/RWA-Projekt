<?php
session_start();
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Uspjeh</title>

    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	  <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="../css/main.css" rel="stylesheet" type="text/css">
  </head>
  <body>
    <div class="container-fluid logScreen flexcol">
      <h3 class="logTitle text-center">
        Uspjeh!
      </h3>
      <div class="logForm flexcol text-center" style="color: #FFF;">
          <?php
          if( isset($_SESSION['message']) AND !empty($_SESSION['message']) ):
              echo $_SESSION['message'];
          else:
              header( "location: index.php" );
          endif;
          ?>
        <a href="index.php" class="btn btn-success loginButton">Home</a>
      </div>
    </div>
  </body>
</html>
