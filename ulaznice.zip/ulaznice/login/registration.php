<?php

$_SESSION['id'] = $user['id'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['first_name'] = $_POST['firstname'];
$_SESSION['last_name'] = $_POST['lastname'];

$first_name = $mysqli->escape_string($_POST['firstname']);
$last_name = $mysqli->escape_string($_POST['lastname']);
$email = $mysqli->escape_string($_POST['email']);
$password = $mysqli->escape_string(password_hash($_POST['password'], PASSWORD_BCRYPT));
$hash = $mysqli->escape_string( md5( rand(0,1000) ) );

$result = $mysqli->query("SELECT * FROM users WHERE email='$email'") or die($mysqli->error());

if ( $result->num_rows > 0 ) {

    $_SESSION['message'] = 'Korisnik s ovom adresom već postoji.';
    header("location: error.php");
}

else if($_POST['password'] != $_POST['confirm_password']){
    $_SESSION['message'] = "Lozinke se ne podudaraju.";
    header("location: error.php");
}

else {
    $sql = "INSERT INTO users (first_name, last_name, email, password, hash, active, account_type) "
            . "VALUES ('$first_name','$last_name','$email','$password', '$hash','1', 'user')";

    if ( $mysqli->query($sql) ){

        $_SESSION['active'] = 1;
        $_SESSION['logged_in'] = true;
        $_SESSION['message'] = 'Registracija uspješna.';
        header("location: success.php");
    }

    else {
        $_SESSION['message'] = 'Registracija neuspješna.';
        header("location: error.php");
    }

    die();
}

?>
